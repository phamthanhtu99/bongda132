create trigger updatect ON chitiethoadon FOR UPDATE  AS
             begin
                 declare @hoadom int,  @monan int,@soluong int
                 select @hoadom=hoadon,@monan=monan,@soluong=soluong from  chitiethoadon where soluong =0
                 if(@soluong)=0
                    delete chitiethoadon where hoadon =@hoadom and monan=@monan
             end
go

