create function tienthuvao( @ngay date, @ngay1 date)
 returns money
    begin
        declare @doanhthu money

        set @doanhthu = (select sum(CTDH.donGia* CTDH.soLuongDat) from DonDatHang_HoaDon as dh join ChiTietDoHang CTDH on dh.maDH = CTDH.maDH
        where  dh.ngayThanhToan between @ngay and @ngay1)
        return @doanhthu
    end
go

