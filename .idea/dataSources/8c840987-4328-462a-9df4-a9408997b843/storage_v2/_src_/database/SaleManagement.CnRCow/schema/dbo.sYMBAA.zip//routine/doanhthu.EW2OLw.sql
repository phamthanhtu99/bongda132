create procedure doanhthu(@doanhthu money)as
    begin
        select format(sum(c.soLuongDat * c.donGia),'#,##0'), MONTH(hd.ngayThanhToan)  from DonDatHang_HoaDon as hd join ChiTietDoHang C on hd.maDH = C.maDH
        group by MONTH(hd.ngayThanhToan)
        having sum(c.soLuongDat * c.donGia)>@doanhthu
    end
go

