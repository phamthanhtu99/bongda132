create procedure  thongkekhachmuahang as
    begin
        select  count(DonDatHang_HoaDon.khachHang),DonDatHang_HoaDon.khachHang
        from DonDatHang_HoaDon group by DonDatHang_HoaDon.khachHang
    end
go

