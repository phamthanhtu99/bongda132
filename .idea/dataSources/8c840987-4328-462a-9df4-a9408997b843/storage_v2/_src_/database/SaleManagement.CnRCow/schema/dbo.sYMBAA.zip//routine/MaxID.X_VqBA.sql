create proc MaxID @table varchar(50), @id int output
    as
    begin
        if (@table like 'sanpham')
            select @id = MAX(right(maSP, 3)) from sanpham
        if (@table like 'KhachHang')
            select @id = MAX(right(MaKH, 3)) from KhachHang
        if (@table like 'NhanVien')
            select @id = MAX(right(maNV, 3)) from NhanVien
        if (@table like 'NhaCungCap' )
            select @id= MAX(right(NhaCungCap.maNCC,3)) from NhaCungCap
        if (@table like 'NhaSanXuat' )
            select @id= MAX(right(NhaSanXuat.maNSX,2)) from NhaSanXuat
        if (@table like 'DonDatHang_HoaDon' )
            select @id= MAX(right(DonDatHang_HoaDon.maDH,5)) from DonDatHang_HoaDon
    end
go

