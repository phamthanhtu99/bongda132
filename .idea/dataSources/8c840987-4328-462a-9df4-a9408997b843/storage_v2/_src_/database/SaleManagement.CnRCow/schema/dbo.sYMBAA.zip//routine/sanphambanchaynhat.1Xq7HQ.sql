create procedure sanphambanchaynhat(@ngaythangnam date) as
    begin
        select  sum(soLuongDat), sp.maSP from
        SanPham as sp join ChiTietDoHang CTDH on sp.maSP = CTDH.maSP join DonDatHang_HoaDon DDHHD on DDHHD.maDH = CTDH.maDH
        where DDHHD.ngayThanhToan=@ngaythangnam group by sp.maSP
    end
go

