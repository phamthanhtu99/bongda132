CREATE proc CompactID @table varchar(50), @Ma varchar(3) output
        as
        begin
            if (@table like 'sanpham')
                set @Ma = 'SP'
            if (@table like 'KhachHang')
                set @Ma = 'KH'
            if (@table like 'NhanVien')
                set @Ma = 'NV'
            if (@table like 'NhaCungCap' )
                set @Ma= 'NCC'
            if (@table like 'NhaSanXuat' )
                set @Ma=  'NSX'
            if (@table like 'DonDatHang_HoaDon' )
                set @Ma=  'HD'
        end
go

