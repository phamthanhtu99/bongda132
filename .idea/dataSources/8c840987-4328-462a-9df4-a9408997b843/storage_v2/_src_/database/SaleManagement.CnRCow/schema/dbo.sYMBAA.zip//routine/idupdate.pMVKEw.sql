CREATE procedure idupdate(@table varchar(50), @id varchar(7) output) as
            begin
                declare @checkdata int
                declare @nametable  varchar(3)
                declare @idmax varchar(5)
                exec dbo.checkdata @table, @checkdata output
                exec  dbo.CompactID @table,@nametable output
                exec dbo.MaxID @table, @idmax output
                if @checkdata = 0
                    set @id = '0'
              if (@table like 'Sanpham' or @table like 'Nhanvien' or @table like 'KhachHang')
                    --id cho table sản phẩm , khách hàng, nhân viên

                     select @id = case
                                 when @idmax >= 0 and @idmax < 9 then @nametable + '00' + CONVERT(char, CONVERT(int, @idmax) + 1)
                                 when @idmax >= 9 and @idmax <99 then  @nametable + '0' + CONVERT(char, CONVERT(int, @idmax) + 1)
                                 when @idmax >= 99  then  @nametable  + CONVERT(char, CONVERT(int, @idmax) + 1)
                        end
             if @table like ('NhaSanXuat')  --id cho table nhà san xuất
                    select @id = case
                                     when @idmax >= 0 and @idmax < 9 then   @nametable + '0'+ CONVERT(char, CONVERT(int, @idmax) + 1)
                                     when @idmax >= 9   then  @nametable  + CONVERT(char, CONVERT(int, @idmax) + 1)

                        end
                if  @table like ('DonDatHang_HoaDon')
                    select @id = case
                                     when @idmax >= 0 and @idmax < 9 then   @nametable + '0000'+ CONVERT(char, CONVERT(int, @idmax) + 1)
                                     when @idmax >= 9 and @idmax <99 then  @nametable +'000' + CONVERT(char, CONVERT(int, @idmax) + 1)
                                     when @idmax >=99 and @idmax <999 then  @nametable +'00' + CONVERT(char, CONVERT(int, @idmax) + 1)
                                     when @idmax >=999 and @idmax <9999 then  @nametable +'0' + CONVERT(char, CONVERT(int, @idmax) + 1)
                                     when @idmax >=9999  then  @nametable  + CONVERT(char, CONVERT(int, @idmax) + 1)
                                    
                        end
            end
go

