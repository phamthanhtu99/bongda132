create procedure  giatrisanpham as
    begin
        select AVG(CT.donGia) as 'Giá trung tình từ sản phẩm' ,
               MAX(ct.donGia) as 'giá nhập cao nhất', MIN(ct.donGia) as 'giá nhập thất nhât' ,  sp.maSP
        from ChiTietDoHang as ct , SanPham as sp where ct.maSP=sp.maSP GROUP BY  sp.maSP
    end
go

