create proc checkdata @table varchar(50), @dem int output
as
begin

    if (@table like 'sanpham')
        select @dem = count(sanpham.maSP) from sanpham
    if (@table like 'KhachHang')
        select @dem = count(KhachHang.MaKH) from KhachHang
    if (@table like 'NhanVien')
        select @dem = count(NhanVien.maNV) from NhanVien
    if (@table like 'NhaCungCap' )
        select @dem = count(NhaCungCap.maNCC) from NhaCungCap
    if (@table like 'NhaSanXuat' )
        select @dem = count(NhaSanXuat.maNSX) from NhaSanXuat
    if (@table like 'DonDatHang_HoaDon' )
        select @dem = count(DonDatHang_HoaDon.maDH) from DonDatHang_HoaDon
end
go

