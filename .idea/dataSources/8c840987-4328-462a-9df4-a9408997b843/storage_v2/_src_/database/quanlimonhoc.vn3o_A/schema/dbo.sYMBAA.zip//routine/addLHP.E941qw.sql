create procedure addLHP @MaLHP char(5) , @MAsv char(12), @stc int output as
    begin
        insert into LHP_SV(MaLHP, MaSV) values (@MaLHP,@MAsv)
        if (@@rowcount=1)
            begin
                update LopHP set  SĐK=SĐK+1 where MaLHP=@MaLHP
                if @@error<>0
                    rollback
                else
                    select @stc=SoTC from HocPhan join LopHP LH on HocPhan.MaHP = LH.MaHP join LHP_SV LS on LH.MaLHP = LS.MaLHP
            end
    end
go

