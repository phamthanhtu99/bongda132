create trigger updateDTBC on LHP_SV for update
    as
    begin
        declare @msv char(12),@mhk char(3)
        select @msv=MaSV , @mhk=MaHK from inserted, LopHP where LopHP.MaLHP=inserted.MaLHP
        update TKHK set DTBC = dbo.TDTB (@msv,@mhk)
        where MaSV=@msv and MaHK=@mhk
    end
go

