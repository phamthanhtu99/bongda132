create function TDTB (@Masv char(12) ,@Mahk char(3))
returns decimal(4,1)
as
    begin
        declare @ttc int , @tc decimal(4,1)
        select @ttc=sum(SoTC) from LopHP,HocPhan,LHP_SV  where
        LopHP.MaLHP=LopHP.MaLHP and LopHP.MaHP=HocPhan.MaHP
        and LHP_SV.MaSV=@Masv and LopHP.MaHK=@Mahk
        select @tc=sum(SoTC*DTKHP) from LopHP,HocPhan,LHP_SV  where
        LopHP.MaLHP=LopHP.MaLHP and LopHP.MaHP=HocPhan.MaHP
        and LHP_SV.MaSV=@Masv and LopHP.MaHK=@Mahk
        return @tc/@ttc
    end
go

