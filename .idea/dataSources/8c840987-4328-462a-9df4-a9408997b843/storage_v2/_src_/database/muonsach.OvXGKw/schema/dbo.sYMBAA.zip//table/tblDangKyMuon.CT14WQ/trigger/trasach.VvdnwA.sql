create trigger trasach on tblDangKyMuon after update as
            begin try
              begin transaction
                  if (select inserted.TinhTrangMuon from inserted ) ='x'
                  update tblSach set SoLuongCon=SoLuongCon+1  from inserted as it where  it.MaSach=tblSach.MaSach and it.TinhTrangMuon='x'
                 else if (select inserted.TinhTrangMuon from inserted ) ='o'
                        update tblSach set SoLuongCon=SoLuongCon-1  from inserted as it where  it.MaSach=tblSach.MaSach and it.TinhTrangMuon='o'
                   commit  transaction
            end try
            begin catch
                rollback transaction
            end catch
go

