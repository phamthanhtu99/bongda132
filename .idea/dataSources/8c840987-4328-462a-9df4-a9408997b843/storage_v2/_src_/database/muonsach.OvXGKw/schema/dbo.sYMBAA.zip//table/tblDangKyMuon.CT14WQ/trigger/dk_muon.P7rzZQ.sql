create trigger  dk_muon on tblDangKyMuon AFTER INSERT as
        begin try
            begin transaction
                UPDATE tblSach set SoLuongCon = SoLuongCon- 1 from inserted as it where  it.MaSach=tblSach.MaSach
                commit transaction
        end try
        begin catch

            rollback  transaction
        end catch
go

