create  proc updateTienphat @MSV char(10),@MaSAch char(5),@Ngaymuon datetime,@Coquahan int, @cohu CHAR(1),@comatsach char(1),@tienphap money output as

    begin
        declare  @tienquahan money =0 ;
        declare  @tienhu money =0 ;
        declare  @tienmat money =0 ;
        if @Coquahan like '1'

                 select  @tienquahan= day(NgayThucHIen-NgayHienTra)*500 from tblMuonTra where MaSV=@MSV and MaSach=@MaSAch and NgayMuon=@Ngaymuon

        if @cohu like 'C'
                select @tienhu= ts.GiaTien -(ts.GiaTien * 70/100) from tblMuonTra join tblSach tS on tS.MaSach = tblMuonTra.MaSach where  tblMuonTra.MaSV=@MSV and tblMuonTra.MaSach=@MaSAch and NgayMuon=@Ngaymuon
        if @comatsach like 'L'
                select @tienmat= ts.GiaTien from tblMuonTra join tblSach tS on tS.MaSach = tblMuonTra.MaSach where   tblMuonTra.MaSV=@MSV and tblMuonTra.MaSach=@MaSAch and NgayMuon=@Ngaymuon
           select @tienphap= @tienquahan+ @tienhu+@tienmat
    end
go

