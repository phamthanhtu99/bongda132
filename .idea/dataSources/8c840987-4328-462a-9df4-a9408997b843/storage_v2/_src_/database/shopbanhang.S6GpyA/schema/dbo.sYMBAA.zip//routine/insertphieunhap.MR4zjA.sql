create procedure insertphieunhap(@nhasanxuat int, @nguoinhap int, @ghichu text, @ngaynhap date=null)
    as
    begin
        DECLARE @ID char(5)
        select @ID = dbo.id('phieunhap')
        print (@ngaynhap)
        if @ngaynhap is null
            INSERT INTO shopbanhang.dbo.phieunhap (MA_phieunhap, nhasanxuat, nguoinhap, ghichu, ngaynhap)
            VALUES (@ID, @nhasanxuat, @nguoinhap, @ghichu, DEFAULT)
         else
            INSERT INTO shopbanhang.dbo.phieunhap (MA_phieunhap, nhasanxuat, nguoinhap, ghichu, ngaynhap)
            VALUES (@ID, @nhasanxuat, @nguoinhap, @ghichu, @ngaynhap)

    end
go

