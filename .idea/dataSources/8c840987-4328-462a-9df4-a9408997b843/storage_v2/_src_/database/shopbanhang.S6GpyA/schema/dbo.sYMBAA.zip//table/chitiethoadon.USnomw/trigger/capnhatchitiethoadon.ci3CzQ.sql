create trigger capnhatchitiethoadon on chitiethoadon AFTER update as
    begin try
        begin transaction
            update sanpham set sanpham.soluong = sanpham.soluong+(select deleted.solong from deleted)
            - (select inserted.solong from inserted) from inserted where sanpham.MA_sanpham=inserted.sanpham
            declare @soluong int
            select @soluong= sanpham.soluong  from sanpham where sanpham.soluong <0
            if @soluong is not  null
                rollback
          COMMIT  transaction
    end try
    begin catch
        rollback  transaction
    end catch
go

