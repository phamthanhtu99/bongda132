create trigger themchitihoadon on chitiethoadon after  insert as
            begin try
                begin transaction

                    update sanpham set sanpham.soluong= sanpham.soluong - inst.solong  from  inserted as inst where inst.sanpham=sanpham.MA_sanpham
                    declare @soluong int
                    select @soluong= sanpham.soluong  from sanpham where sanpham.soluong <0
                    update chitiethoadon set dongia= sanpham.dongiaban from sanpham,inserted where sanpham.MA_sanpham=chitiethoadon.sanpham
                    and chitiethoadon.hoadon= inserted.hoadon
                    and chitiethoadon.sanpham=inserted.sanpham
                    if @soluong is not  null
                            rollback
                COMMIT  transaction
            end try
            begin catch
                ROLLBACK TRANSACTION
            end catch
go

