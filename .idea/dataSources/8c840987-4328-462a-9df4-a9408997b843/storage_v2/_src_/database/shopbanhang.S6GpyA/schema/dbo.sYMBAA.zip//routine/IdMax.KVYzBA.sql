CREATE function IdMax (@table varchar(20))
        returns int
    begin
        DECLARE @ID int
        if (@table = 'sanpham')
            select @ID = MAX(right(MA_sanpham,3)) from sanpham
        if (@table = 'phieunhap')
            select @ID = MAX(right(MA_phieunhap,3))from phieunhap
        return @ID
    end
go

