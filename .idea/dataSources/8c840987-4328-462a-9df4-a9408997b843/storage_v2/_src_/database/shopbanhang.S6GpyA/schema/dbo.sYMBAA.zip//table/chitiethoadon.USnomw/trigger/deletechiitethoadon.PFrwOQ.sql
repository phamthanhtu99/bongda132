create trigger  deletechiitethoadon ON chitiethoadon AFTER DELETE  as

                begin try
                    begin transaction

                        update sanpham set sanpham.soluong= sanpham.soluong +(select  deleted.solong from  deleted) from  deleted as inst where inst.sanpham=sanpham.MA_sanpham
                    COMMIT  transaction
                end try
                begin catch
                    ROLLBACK TRANSACTION
                end catch
go

