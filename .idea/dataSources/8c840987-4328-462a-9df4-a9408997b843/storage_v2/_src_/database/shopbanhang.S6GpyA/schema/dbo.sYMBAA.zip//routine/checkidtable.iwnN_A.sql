CREATE  function checkidtable(@table varchar(20))
    returns int
    begin
        DECLARE  @dem int
        if (@table = 'sanpham')
            select @dem= count(sanpham.MA_sanpham) from sanpham
        if (@table = 'phieunhap')
            select @dem= count(phieunhap.MA_phieunhap) from phieunhap
        return @dem
    end
go

