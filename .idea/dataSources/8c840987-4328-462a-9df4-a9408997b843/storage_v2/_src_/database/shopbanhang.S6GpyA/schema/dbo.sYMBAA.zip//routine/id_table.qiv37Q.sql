CREATE  function id_table(@nametable varchar(20))
returns char(2)
    begin
        DECLARE  @name char(2)
        if (@nametable = 'sanpham')
            set @name='SP'
        if (@nametable = 'phieunhap')
            set @name='PN'
    return @name
    end
go

