create function id(@table char(20))
    returns varchar(5)
as
BEGIN
    DECLARE @ID varchar(5)
    DECLARE @nametable varchar(2)
    DECLARE @dem int
    Select @nametable = dbo.id_table(@table)
    select @dem = dbo.checkidtable(@table)
    if @dem = 0
        set @ID = '0'
    else
        select @ID = dbo.IdMax(@table)
    select @ID = case
                     when @ID >= 0 and @id < 9 then @nametable + '00' + CONVERT(char, CONVERT(int, @ID) + 1)
                     when @ID >= 9 then @nametable + '0' + CONVERT(char, CONVERT(int, @ID) + 1)
        end
    return @ID
end
go

