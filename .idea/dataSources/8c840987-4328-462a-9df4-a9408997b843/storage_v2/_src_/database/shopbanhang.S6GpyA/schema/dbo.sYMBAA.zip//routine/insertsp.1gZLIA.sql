create procedure insertsp(@tensanpham varchar(255), @soluong int, @mota text, @loaisanpham int, @nhacungcap int,
                          @dongia money)
as
begin
    DECLARE @ID char(5)
    select @ID = dbo.id('sanpham')
    INSERT INTO shopbanhang.dbo.sanpham (MA_sanpham, tensanpham, soluong, mota, loaisanpham, nhacungcap, dongiaban)
    VALUES (@ID, @tensanpham, @soluong, @mota, @loaisanpham, @nhacungcap, @dongia)

end ;
go

