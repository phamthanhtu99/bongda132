create trigger insertnhaphang
            on chitietphieunhap
            after INSERT as
        begin
            DECLARE @giatricu int
            select @giatricu = sp.soluong
            from inserted as it join sanpham as sp on it.sanpham = sp.MA_sanpham
            if (select sp.soluong from sanpham as sp, inserted as ist where ist.sanpham = sp.MA_sanpham) = 0
                update sanpham set soluong= inserted.solong from inserted where sanpham.MA_sanpham=inserted.sanpham
            else
                update sanpham
                set sanpham.soluong =@giatricu + ist.solong
                from inserted as ist
                where sanpham.MA_sanpham = ist.sanpham
        end
go

