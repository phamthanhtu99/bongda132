create trigger deletephieunhap on chitietphieunhap after delete  as
            begin
                update sanpham set sanpham.soluong= sanpham.soluong -
                (select  deleted.solong from deleted) from deleted where  sanpham.MA_sanpham=deleted.sanpham
            end
go

