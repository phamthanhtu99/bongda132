create trigger updatenhaphang on chitietphieunhap after update as
        begin

            update sanpham set sanpham.soluong =sanpham.soluong +
            (select inserted.solong from inserted where inserted.sanpham= sanpham.MA_sanpham)
            -(select deleted.solong from deleted where deleted.sanpham=sanpham.MA_sanpham)
            from deleted where sanpham.MA_sanpham=deleted.sanpham

        end
go

